---
sidebar_label: DEFAULT_INTERCEPT_RESOLUTION_PRIORITY
---

# DEFAULT_INTERCEPT_RESOLUTION_PRIORITY variable

The default cooperative request interception resolution priority

#### Signature:

```typescript
DEFAULT_INTERCEPT_RESOLUTION_PRIORITY = 0;
```
