---
sidebar_label: puppeteer
---

# puppeteer variable

#### Signature:

```typescript
puppeteer: PuppeteerNode;
```
