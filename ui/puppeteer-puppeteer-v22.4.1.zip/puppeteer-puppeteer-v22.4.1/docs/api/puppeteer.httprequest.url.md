---
sidebar_label: HTTPRequest.url
---

# HTTPRequest.url() method

The URL of the request

#### Signature:

```typescript
class HTTPRequest {
  abstract url(): string;
}
```

**Returns:**

string
