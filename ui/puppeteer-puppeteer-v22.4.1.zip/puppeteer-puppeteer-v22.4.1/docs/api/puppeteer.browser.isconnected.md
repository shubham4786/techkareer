---
sidebar_label: Browser.isConnected
---

# Browser.isConnected() method

> Warning: This API is now obsolete.
>
> Use [Browser.connected](./puppeteer.browser.md).

Whether Puppeteer is connected to this [browser](./puppeteer.browser.md).

#### Signature:

```typescript
class Browser {
  isConnected(): boolean;
}
```

**Returns:**

boolean
