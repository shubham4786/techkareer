---
sidebar_label: Frame.childFrames
---

# Frame.childFrames() method

An array of child frames.

#### Signature:

```typescript
class Frame {
  abstract childFrames(): Frame[];
}
```

**Returns:**

[Frame](./puppeteer.frame.md)\[\]
