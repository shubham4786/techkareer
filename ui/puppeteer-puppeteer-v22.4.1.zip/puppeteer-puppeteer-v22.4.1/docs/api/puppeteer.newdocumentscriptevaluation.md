---
sidebar_label: NewDocumentScriptEvaluation
---

# NewDocumentScriptEvaluation interface

#### Signature:

```typescript
export interface NewDocumentScriptEvaluation
```

## Properties

| Property   | Modifiers | Type   | Description | Default |
| ---------- | --------- | ------ | ----------- | ------- |
| identifier |           | string |             |         |
