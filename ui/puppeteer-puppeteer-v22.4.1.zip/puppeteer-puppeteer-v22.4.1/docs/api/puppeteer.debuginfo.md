---
sidebar_label: DebugInfo
---

# DebugInfo interface

#### Signature:

```typescript
export interface DebugInfo
```

## Properties

| Property              | Modifiers | Type      | Description | Default |
| --------------------- | --------- | --------- | ----------- | ------- |
| pendingProtocolErrors |           | Error\[\] |             |         |
