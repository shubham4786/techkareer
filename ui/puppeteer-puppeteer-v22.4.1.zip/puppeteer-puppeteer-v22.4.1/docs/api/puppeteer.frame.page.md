---
sidebar_label: Frame.page
---

# Frame.page() method

The page associated with the frame.

#### Signature:

```typescript
class Frame {
  abstract page(): Page;
}
```

**Returns:**

[Page](./puppeteer.page.md)
