---
sidebar_label: Quad
---

# Quad type

#### Signature:

```typescript
export type Quad = [Point, Point, Point, Point];
```

**References:** [Point](./puppeteer.point.md)
