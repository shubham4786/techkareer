---
sidebar_label: ConsoleMessage.text
---

# ConsoleMessage.text() method

The text of the console message.

#### Signature:

```typescript
class ConsoleMessage {
  text(): string;
}
```

**Returns:**

string
