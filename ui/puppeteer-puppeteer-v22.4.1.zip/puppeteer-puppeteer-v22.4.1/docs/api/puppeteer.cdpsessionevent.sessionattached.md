---
sidebar_label: CDPSessionEvent.SessionAttached
---

# CDPSessionEvent.SessionAttached variable

#### Signature:

```typescript
SessionAttached: 'sessionattached';
```
