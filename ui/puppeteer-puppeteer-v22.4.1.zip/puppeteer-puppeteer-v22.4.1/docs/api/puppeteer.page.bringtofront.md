---
sidebar_label: Page.bringToFront
---

# Page.bringToFront() method

Brings page to front (activates tab).

#### Signature:

```typescript
class Page {
  abstract bringToFront(): Promise<void>;
}
```

**Returns:**

Promise&lt;void&gt;
