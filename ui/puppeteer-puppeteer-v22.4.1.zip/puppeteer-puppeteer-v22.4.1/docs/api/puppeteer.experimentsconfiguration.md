---
sidebar_label: ExperimentsConfiguration
---

# ExperimentsConfiguration type

Defines experiment options for Puppeteer.

See individual properties for more information.

#### Signature:

```typescript
export type ExperimentsConfiguration = Record<string, never>;
```
