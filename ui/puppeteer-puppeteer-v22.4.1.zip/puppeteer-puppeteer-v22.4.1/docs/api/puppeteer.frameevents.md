---
sidebar_label: FrameEvents
---

# FrameEvents interface

#### Signature:

```typescript
export interface FrameEvents extends Record<EventType, unknown>
```

**Extends:** Record&lt;[EventType](./puppeteer.eventtype.md), unknown&gt;
