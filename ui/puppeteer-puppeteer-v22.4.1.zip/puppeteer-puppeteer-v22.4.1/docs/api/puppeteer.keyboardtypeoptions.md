---
sidebar_label: KeyboardTypeOptions
---

# KeyboardTypeOptions interface

#### Signature:

```typescript
export interface KeyboardTypeOptions
```

## Properties

| Property | Modifiers             | Type   | Description | Default |
| -------- | --------------------- | ------ | ----------- | ------- |
| delay    | <code>optional</code> | number |             |         |
