---
sidebar_label: ElementHandle.drop_1
---

# ElementHandle.drop() method

> Warning: This API is now obsolete.
>
> No longer supported.

#### Signature:

```typescript
class ElementHandle {
  drop(
    this: ElementHandle<Element>,
    data?: Protocol.Input.DragData
  ): Promise<void>;
}
```

## Parameters

| Parameter | Type                                                         | Description  |
| --------- | ------------------------------------------------------------ | ------------ |
| this      | [ElementHandle](./puppeteer.elementhandle.md)&lt;Element&gt; |              |
| data      | Protocol.Input.DragData                                      | _(Optional)_ |

**Returns:**

Promise&lt;void&gt;
