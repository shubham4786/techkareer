---
sidebar_label: ElementHandle.contentFrame_1
---

# ElementHandle.contentFrame() method

#### Signature:

```typescript
class ElementHandle {
  abstract contentFrame(): Promise<Frame | null>;
}
```

**Returns:**

Promise&lt;[Frame](./puppeteer.frame.md) \| null&gt;
