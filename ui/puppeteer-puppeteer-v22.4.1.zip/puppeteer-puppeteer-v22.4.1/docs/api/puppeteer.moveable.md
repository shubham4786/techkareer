---
sidebar_label: Moveable
---

# Moveable interface

#### Signature:

```typescript
export interface Moveable
```

## Methods

| Method                                 | Description                      |
| -------------------------------------- | -------------------------------- |
| [move()](./puppeteer.moveable.move.md) | Moves the resource when 'using'. |
