---
sidebar_label: CommonEventEmitter.listenerCount
---

# CommonEventEmitter.listenerCount() method

#### Signature:

```typescript
interface CommonEventEmitter {
  listenerCount(event: keyof Events): number;
}
```

## Parameters

| Parameter | Type         | Description |
| --------- | ------------ | ----------- |
| event     | keyof Events |             |

**Returns:**

number
