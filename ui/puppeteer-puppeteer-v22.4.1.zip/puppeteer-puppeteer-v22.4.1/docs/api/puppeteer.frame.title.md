---
sidebar_label: Frame.title
---

# Frame.title() method

The frame's title.

#### Signature:

```typescript
class Frame {
  title(): Promise<string>;
}
```

**Returns:**

Promise&lt;string&gt;
