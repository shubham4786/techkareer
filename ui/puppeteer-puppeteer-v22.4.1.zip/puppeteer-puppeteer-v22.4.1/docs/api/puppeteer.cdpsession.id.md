---
sidebar_label: CDPSession.id
---

# CDPSession.id() method

Returns the session's id.

#### Signature:

```typescript
class CDPSession {
  abstract id(): string;
}
```

**Returns:**

string
