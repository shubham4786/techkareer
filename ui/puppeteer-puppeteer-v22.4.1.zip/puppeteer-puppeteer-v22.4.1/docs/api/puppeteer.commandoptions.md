---
sidebar_label: CommandOptions
---

# CommandOptions interface

#### Signature:

```typescript
export interface CommandOptions
```

## Properties

| Property | Modifiers | Type   | Description | Default |
| -------- | --------- | ------ | ----------- | ------- |
| timeout  |           | number |             |         |
