---
sidebar_label: CDPSession.connection
---

# CDPSession.connection() method

#### Signature:

```typescript
class CDPSession {
  abstract connection(): Connection | undefined;
}
```

**Returns:**

[Connection](./puppeteer.connection.md) \| undefined
