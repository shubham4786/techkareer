---
sidebar_label: Credentials
---

# Credentials interface

#### Signature:

```typescript
export interface Credentials
```

## Properties

| Property | Modifiers | Type   | Description | Default |
| -------- | --------- | ------ | ----------- | ------- |
| password |           | string |             |         |
| username |           | string |             |         |
