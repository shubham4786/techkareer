---
sidebar_label: KeyDownOptions
---

# KeyDownOptions interface

#### Signature:

```typescript
export interface KeyDownOptions
```

## Properties

| Property | Modifiers             | Type       | Description | Default |
| -------- | --------------------- | ---------- | ----------- | ------- |
| commands | <code>optional</code> | string\[\] |             |         |
| text     | <code>optional</code> | string     |             |         |
