---
sidebar_label: Frame.url
---

# Frame.url() method

The frame's URL.

#### Signature:

```typescript
class Frame {
  abstract url(): string;
}
```

**Returns:**

string
