---
sidebar_label: Moveable.move
---

# Moveable.move() method

Moves the resource when 'using'.

#### Signature:

```typescript
interface Moveable {
  move(): this;
}
```

**Returns:**

this
