---
sidebar_label: ActionResult
---

# ActionResult type

#### Signature:

```typescript
export type ActionResult = 'continue' | 'abort' | 'respond';
```
