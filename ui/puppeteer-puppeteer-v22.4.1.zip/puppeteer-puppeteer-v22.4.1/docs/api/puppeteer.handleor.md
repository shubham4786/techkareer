---
sidebar_label: HandleOr
---

# HandleOr type

#### Signature:

```typescript
export type HandleOr<T> = HandleFor<T> | JSHandle<T> | T;
```

**References:** [HandleFor](./puppeteer.handlefor.md), [JSHandle](./puppeteer.jshandle.md)
