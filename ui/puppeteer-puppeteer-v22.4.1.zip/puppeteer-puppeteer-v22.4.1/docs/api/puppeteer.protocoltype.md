---
sidebar_label: ProtocolType
---

# ProtocolType type

#### Signature:

```typescript
export type ProtocolType = 'cdp' | 'webDriverBiDi';
```
