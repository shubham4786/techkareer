---
sidebar_label: customQueryHandlerNames
---

# customQueryHandlerNames() function

> Warning: This API is now obsolete.
>
> Import [Puppeteer](./puppeteer.puppeteer.md) and use the static method [Puppeteer.customQueryHandlerNames()](./puppeteer.puppeteer.customqueryhandlernames.md)

#### Signature:

```typescript
export declare function customQueryHandlerNames(): string[];
```

**Returns:**

string\[\]
