---
sidebar_label: Awaitable
---

# Awaitable type

#### Signature:

```typescript
export type Awaitable<T> = T | PromiseLike<T>;
```
