---
sidebar_label: registerCustomQueryHandler
---

# registerCustomQueryHandler() function

> Warning: This API is now obsolete.
>
> Import [Puppeteer](./puppeteer.puppeteer.md) and use the static method [Puppeteer.registerCustomQueryHandler()](./puppeteer.puppeteer.registercustomqueryhandler.md)

#### Signature:

```typescript
export declare function registerCustomQueryHandler(
  name: string,
  handler: CustomQueryHandler
): void;
```

## Parameters

| Parameter | Type                                                    | Description |
| --------- | ------------------------------------------------------- | ----------- |
| name      | string                                                  |             |
| handler   | [CustomQueryHandler](./puppeteer.customqueryhandler.md) |             |

**Returns:**

void
