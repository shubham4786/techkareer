---
sidebar_label: CDPSessionEvent.SessionDetached
---

# CDPSessionEvent.SessionDetached variable

#### Signature:

```typescript
SessionDetached: 'sessiondetached';
```
