---
sidebar_label: ConnectionTransport.close
---

# ConnectionTransport.close() method

#### Signature:

```typescript
interface ConnectionTransport {
  close(): void;
}
```

**Returns:**

void
