---
sidebar_label: JSCoverage.stop
---

# JSCoverage.stop() method

#### Signature:

```typescript
class JSCoverage {
  stop(): Promise<JSCoverageEntry[]>;
}
```

**Returns:**

Promise&lt;[JSCoverageEntry](./puppeteer.jscoverageentry.md)\[\]&gt;
