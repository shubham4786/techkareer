---
sidebar_label: Frame.isDetached
---

# Frame.isDetached() method

> Warning: This API is now obsolete.
>
> Use the `detached` getter.

Is`true` if the frame has been detached. Otherwise, `false`.

#### Signature:

```typescript
class Frame {
  isDetached(): boolean;
}
```

**Returns:**

boolean
