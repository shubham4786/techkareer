---
sidebar_label: ActionOptions
---

# ActionOptions interface

#### Signature:

```typescript
export interface ActionOptions
```

## Properties

| Property | Modifiers             | Type        | Description | Default |
| -------- | --------------------- | ----------- | ----------- | ------- |
| signal   | <code>optional</code> | AbortSignal |             |         |
