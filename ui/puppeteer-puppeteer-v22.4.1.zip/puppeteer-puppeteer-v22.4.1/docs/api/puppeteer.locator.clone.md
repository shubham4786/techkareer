---
sidebar_label: Locator.clone
---

# Locator.clone() method

Clones the locator.

#### Signature:

```typescript
class Locator {
  clone(): Locator<T>;
}
```

**Returns:**

[Locator](./puppeteer.locator.md)&lt;T&gt;
