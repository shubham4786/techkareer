---
sidebar_label: Dialog.message
---

# Dialog.message() method

The message displayed in the dialog.

#### Signature:

```typescript
class Dialog {
  message(): string;
}
```

**Returns:**

string
