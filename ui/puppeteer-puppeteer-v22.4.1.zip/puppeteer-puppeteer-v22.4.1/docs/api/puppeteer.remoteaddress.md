---
sidebar_label: RemoteAddress
---

# RemoteAddress interface

#### Signature:

```typescript
export interface RemoteAddress
```

## Properties

| Property | Modifiers             | Type   | Description | Default |
| -------- | --------------------- | ------ | ----------- | ------- |
| ip       | <code>optional</code> | string |             |         |
| port     | <code>optional</code> | number |             |         |
