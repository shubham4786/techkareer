---
sidebar_label: Page.getDefaultTimeout
---

# Page.getDefaultTimeout() method

Maximum time in milliseconds.

#### Signature:

```typescript
class Page {
  abstract getDefaultTimeout(): number;
}
```

**Returns:**

number
