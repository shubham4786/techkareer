---
sidebar_label: LowerCasePaperFormat
---

# LowerCasePaperFormat type

#### Signature:

```typescript
export type LowerCasePaperFormat =
  | 'letter'
  | 'legal'
  | 'tabloid'
  | 'ledger'
  | 'a0'
  | 'a1'
  | 'a2'
  | 'a3'
  | 'a4'
  | 'a5'
  | 'a6';
```
