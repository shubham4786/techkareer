---
sidebar_label: MouseWheelOptions
---

# MouseWheelOptions interface

#### Signature:

```typescript
export interface MouseWheelOptions
```

## Properties

| Property | Modifiers             | Type   | Description | Default |
| -------- | --------------------- | ------ | ----------- | ------- |
| deltaX   | <code>optional</code> | number |             |         |
| deltaY   | <code>optional</code> | number |             |         |
