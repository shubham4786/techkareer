---
sidebar_label: CSSCoverage.stop
---

# CSSCoverage.stop() method

#### Signature:

```typescript
class CSSCoverage {
  stop(): Promise<CoverageEntry[]>;
}
```

**Returns:**

Promise&lt;[CoverageEntry](./puppeteer.coverageentry.md)\[\]&gt;
