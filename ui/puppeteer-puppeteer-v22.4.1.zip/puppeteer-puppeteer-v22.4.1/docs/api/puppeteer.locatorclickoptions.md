---
sidebar_label: LocatorClickOptions
---

# LocatorClickOptions type

#### Signature:

```typescript
export type LocatorClickOptions = ClickOptions & ActionOptions;
```

**References:** [ClickOptions](./puppeteer.clickoptions.md), [ActionOptions](./puppeteer.actionoptions.md)
