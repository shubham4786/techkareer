---
sidebar_label: Puppeteer.clearCustomQueryHandlers
---

# Puppeteer.clearCustomQueryHandlers() method

Unregisters all custom query handlers.

#### Signature:

```typescript
class Puppeteer {
  static clearCustomQueryHandlers(): void;
}
```

**Returns:**

void
